<div id="popup-box1" class="popup-position">
<div id="popup-wrapper">
<div id="popup-container">
    <div id="popup-head-color4">
    <p style="text-align:right !important; font-family: 'Courier New', Courier, monospace;font-size:15px;"><a href= "javascript:void(0)" onclick="toggle_visibility('popup-box1')"><font color="#FFF"> X </font></a></p>
    <p style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif;font-size:16px;"> Formulario Agregar Inmueble </p>
    </div>
    <br>
    <form action="add_customer.php" method="POST">
    <table border="0" align="center">
    
    <tr>
    <td align="right">Nombre:</td>
    <td><input type="text" id="txtbox" name="name" placeholder="Nombre Cliente" required><br></td>
    </tr>
    
    <tr>
    <td align="right">Contacto:</td>
    <td><input type="text" id="txtbox" name="contact"  placeholder="Contacto" required><br></td>
    </tr>
    
    <tr>
    <td align="right">Direccion:</td>
    <td><input type="text" id="txtbox" name="address" placeholder="Direccion" required><br></td>
    </tr>
    
    <tr>
    <td align="right">Notas:</td>
    <td><input type="text" id="txtbox" name="note" placeholder="Notas" required><br></td>
    </tr>

    <br>
    <tr  align="left">
    <td>&nbsp;  </td>
    <td><input type="SUBMIT" id="btnnav" value="Enviar"></a></td>
    </tr>
    
    </table>
    </form>

</div>
</div>
</div>