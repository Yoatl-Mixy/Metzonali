<table border="0" cellpadding="15px" align="center"; style="size: 12px; font-family: 'Courier New', Courier, monospace; color: #FFF; font-size: 12px;">
<tr>
	<td>
    &copy; 2017 UTIM  |  Diseñado por:<a>E1_9BX</a>	
    </td>
</tr>
</table>