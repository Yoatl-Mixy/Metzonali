<table border="0" cellpadding="0" cellspacing="10" align="center">
	<tr align="center">
        <td><a href="products.php"><input type="button" id="bdnav2"></a></td>
        <td><a href="customers.php"><input type="button" id="bdnav3"></a></td>
    </tr>
    <tr>
    	<td><a href="supplier.php"><input type="button" id="bdnav4"></a></td>
        <td><a href="logout.php"><input type="button" id="bdnav6"></a></td>
    </tr>
</table>